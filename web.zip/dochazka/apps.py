from django.apps import AppConfig


class DochazkaConfig(AppConfig):
    name = 'dochazka'
