from django.shortcuts import render
from django import forms
import re
from colorama import init, Fore, Back, Style


def index(request):
    print(request.FILES)
    print(len(request.FILES))
    if request.method == 'POST' and len(request.FILES)==2:
        try:
            print("ud")
            print(request.FILES)
            meeting = request.FILES['meeting'].read().decode('utf-16').splitlines()
            trida = request.FILES['trida'].read().decode('utf-8').splitlines()
            print(trida)
            print(meeting)
            zaci = []
            zaci_navsteva = {}
            text = []
      
            for radek in trida:
                radek = radek.replace('\t',' ')
                radek = radek.replace('\n','')
                zaci.append(radek)
                zaci_navsteva[radek] = ""

            result = "<p>Vyhodnocení docházky proběhlo v pořádku. Pokud nevidíte tabulku s docházkou, zkuste to prosím znovu.</p><table>"
            for zak in zaci:
                i = 0
                text = "\t"
                for radek in meeting:
                    if radek.find(zak) != -1:
                        i+=1
                        casti=re.split(r'\t+', radek)
                        cast=casti[2]
                        casti=re.split(r' +', radek)
                        text += casti.pop().replace('\n','') +"|" 
                if i == 0:
                     result+= "<tr style=\"background-color: LightCoral;\"><td>"+ zak + "</td><td>Nepřipojil</td><td></td></tr>"
                else:
                    zaci_navsteva[zak] = "Připojil" + str(i)
                    result+="<tr style=\"background-color: LightGreen;\"><td>"+zak + "</td><td> Připojil </td><td>" +text +"</td></tr>"
                       

            result+="</table>"
            return render(request,"dochazka/index.html",dict(result=result))
        except:
            return render(request,"dochazka/index.html",dict(result="<p style=\" color: red;\"> Během zjišťování docházky, došlo k chybě. zkontrolujte, zda umisťujete soubory do správných kolonek.</p>"))
            
        
    elif request.method == 'POST':
        try:
            if request.POST['heslo'] == 'Sportovni2021':
                return render(request,"dochazka/index.html")
            else:
                return render(request,"dochazka/heslo.html",dict(result="<p style=\" color: red;\" >Zadané heslo není správně </p>"))
            return render(request,"dochazka/index.html",dict(result=result))
        except: 
            return render(request,"dochazka/heslo.html",dict(result="<p style=\" color: red;\" >Nebyl zadán jeden nebo oba soubory. Zadejte heslo a zkuste to prosím znovu! </p>"))
            
      
    else:
        return render(request,"dochazka/heslo.html")

# Create your views here.
